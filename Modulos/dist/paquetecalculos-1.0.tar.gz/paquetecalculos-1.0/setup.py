from setuptools import setup

setup(

    name="paquetecalculos",#cualquier nombre
    version="1.0",#cualquier numero
    description="Paquete de redondeo y potencia",
    author="Kozur Anibal Martin",
    author_email="anibalkozur@hotmaiul.com",
    #url="direccion de pagina"
    packages=["calculos.redondeo_potencia"]
    #en consola de cimando cmd se pone
    #python setup.py sdist
    #para que sea una paquete distribuible
)