def potencia(base, exponente):
    print("El resultado de la potencia es: ", base**exponente)

def redonedear(numero):
    print("El numero redondeado es: ", round(numero))